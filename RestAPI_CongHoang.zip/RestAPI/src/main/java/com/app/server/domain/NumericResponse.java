package com.app.server.domain;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class NumericResponse {

    BigDecimal output;
}
